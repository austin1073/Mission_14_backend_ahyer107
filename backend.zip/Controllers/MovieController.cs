﻿using Microsoft.AspNetCore.Mvc;
using Mission14_ahyer107_backend.Data;

namespace Mission14_ahyer107_backend.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MovieController : Controller
    {
        private MovieDbContext context;

        public MovieController(MovieDbContext temp)
        {
            context = temp;
        }

        public IEnumerable<Movie> Get()
        {
            var x = context.Movies
                .Where(m => m.Edited == "Yes")
                .OrderBy(m => m.Title)
                .ToArray();


            return x;
        }

    }
}
